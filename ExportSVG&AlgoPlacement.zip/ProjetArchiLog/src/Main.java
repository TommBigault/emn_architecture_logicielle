import java.io.File;

public class Main {
	
	public static void main(String[] args) {
		ExportSVG e = new ExportSVG() ;
		e.addln(e.start_graph());
		e.addln("A -> B ");
		e.addln("C -> B [style=dotted,label=\"Interface\"] ");
		e.addln(e.end_graph());
		System.out.println(e.getDotSource());
		
		
		File out = new File("./out."+ExportSVG.fileType);  
		e.writeSVG(e.getGraph(e.getDotSource()), out );
	}
	

}
